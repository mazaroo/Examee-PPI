var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var fs = require('fs');
var path = require('path');

var app = express();
var PORT = process.env.PORT || 3000;

// 🚨 Atualizado: agora usando a pasta "HTML.CSS"
app.use(express.static('HTML.CSS'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
    secret: 'segredo',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 30 * 60 * 1000 }
}));

// 🚨 Atualizado: JSON/ ao invés de data/
function lerUsuarios() {
    if (!fs.existsSync('./JSON/usuarios.json')) return [];
    return JSON.parse(fs.readFileSync('./JSON/usuarios.json'));
}
function salvarUsuarios(usuarios) {
    fs.writeFileSync('./JSON/usuarios.json', JSON.stringify(usuarios, null, 2));
}
function lerMensagens() {
    if (!fs.existsSync('./JSON/mensagens.json')) return [];
    return JSON.parse(fs.readFileSync('./JSON/mensagens.json'));
}
function salvarMensagens(mensagens) {
    fs.writeFileSync('./JSON/mensagens.json', JSON.stringify(mensagens, null, 2));
}

var assuntos = ['Futebol', 'Games', 'Carros', 'Música', 'Filmes'];

function requireLogin(req, res, next) {
    if (req.session && req.session.logado) {
        next();
    } else {
        res.redirect('/login.html');
    }
}

app.get('/', (req, res) => {
    res.redirect('/login.html');
});

app.post('/login', (req, res) => {
    var { usuario, senha } = req.body;
    if (usuario === 'admin' && senha === '1234') {
        req.session.logado = true;
        res.cookie('ultimoAcesso', new Date().toLocaleString(), { maxAge: 365 * 24 * 60 * 60 * 1000 });
        res.redirect('/menu');
    } else {
        res.sendFile(path.join(__dirname, 'HTML.CSS', 'login.html'));
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login.html');
});

app.get('/menu', requireLogin, (req, res) => {
    var ultimoAcesso = req.cookies.ultimoAcesso || 'Primeiro acesso';
    res.send(`
        <html>
        <head><title>Menu</title></head>
        <body>
            <h1>Menu do Sistema</h1>
            <p>Último acesso: ${ultimoAcesso}</p>
            <ul>
                <li><a href="/cadastroUsuario.html">Cadastro de Usuários</a></li>
                <li><a href="/batepapo">Bate-papo</a></li>
                <li><a href="/logout">Logout</a></li>
            </ul>
        </body>
        </html>
    `);
});

app.get('/cadastroUsuario.html', requireLogin, (req, res) => {
    var opcoes = assuntos.map(a => `<option value="${a}">${a}</option>`).join('');

    res.send(`
        <html>
        <head><title>Cadastro</title></head>
        <body>
            <h1>Cadastro de Usuário</h1>
            <form method="POST" action="/cadastrarUsuario">
                Nome: <input name="nome" required><br>
                Data de Nascimento: <input type="date" name="nascimento" required><br>
                Nickname: <input name="nickname" required><br>
                E-mail: <input type="email" name="email" required><br>
                Senha: <input type="password" name="senha" required><br>
                Assunto preferido: <select name="assunto" required>${opcoes}</select><br>
                <button type="submit">Cadastrar</button>
            </form>
            <a href="/menu">Voltar ao menu</a>
        </body>
        </html>
    `);
});

app.post('/cadastrarUsuario', requireLogin, (req, res) => {
    var { nome, nascimento, nickname, email, senha, assunto } = req.body;

    var erros = [];
    if (!nome || !nascimento || !nickname || !email || !senha || !assunto) {
        erros.push('Todos os campos são obrigatórios.');
    }

    if (!assuntos.includes(assunto)) {
        erros.push('Assunto inválido.');
    }

    var usuarios = lerUsuarios();
    if (usuarios.find(u => u.email === email)) {
        erros.push('E-mail já cadastrado.');
    }

    if (erros.length > 0) {
        return res.send(`
            <p>${erros.join('<br>')}</p>
            <a href="/cadastroUsuario.html">Voltar</a>`);
    }

    usuarios.push({ nome, nascimento, nickname, email, senha, assunto });
    salvarUsuarios(usuarios);

    var lista = usuarios.map(u => `<tr><td>${u.nome}</td><td>${u.nickname}</td><td>${u.assunto}</td></tr>`).join('');
    res.send(`
        <html>
        <head><title>Usuários Cadastrados</title></head>
        <body>
            <h2>Usuários cadastrados</h2>
            <table border="1">
                <tr><th>Nome</th><th>Nickname</th><th>Assunto</th></tr>
                ${lista}
            </table>
            <a href="/cadastroUsuario.html">Novo cadastro</a> | <a href="/menu">Menu</a>
        </body>
        </html>
    `);
});

app.get('/batepapo', requireLogin, (req, res) => {
    var assunto = req.query.assunto;
    if (!assunto || !assuntos.includes(assunto)) {
        var opcoes = assuntos.map(a => `<option value="${a}">${a}</option>`).join('');
        return res.send(`
            <html>
            <head><title>Bate-papo</title></head>
            <body>
                <h1>Bate-papo</h1>
                <form method="GET" action="/batepapo">
                    Escolha o assunto: <select name="assunto" required>${opcoes}</select>
                    <button type="submit">Ver mensagens</button>
                </form>
                <a href="/menu">Voltar ao menu</a>
            </body>
            </html>
        `);
    }

    var usuarios = lerUsuarios().filter(u => u.assunto === assunto);
    var mensagens = lerMensagens().filter(m => m.assunto === assunto);

    var opcoesUsuarios = usuarios.map(u => `<option value="${u.nickname}">${u.nome}</option>`).join('');
    var listaMensagens = mensagens.map(m => `<tr><td>${m.dataHora}</td><td>${m.usuario}</td><td>${m.texto}</td></tr>`).join('');

    res.send(`
        <html>
        <head><title>Bate-papo</title></head>
        <body>
            <h1>Bate-papo - ${assunto}</h1>
            <form method="POST" action="/postarMensagem">
                <input type="hidden" name="assunto" value="${assunto}">
                Usuário: <select name="usuario" required>${opcoesUsuarios}</select><br>
                Mensagem: <input name="mensagem" required><br>
                <button type="submit">Enviar</button>
            </form>
            <h2>Mensagens</h2>
            <table border="1">
                <tr><th>Data/Hora</th><th>Usuário</th><th>Mensagem</th></tr>
                ${listaMensagens}
            </table>
            <a href="/batepapo">Escolher outro assunto</a> | <a href="/menu">Menu</a>
        </body>
        </html>
    `);
});

app.post('/postarMensagem', requireLogin, (req, res) => {
    var { assunto, usuario, mensagem } = req.body;
    var erros = [];

    if (!assunto || !usuario || !mensagem) {
        erros.push('Todos os campos são obrigatórios.');
    }

    var usuarios = lerUsuarios().filter(u => u.assunto === assunto);
    if (!usuarios.find(u => u.nickname === usuario)) {
        erros.push('Usuário inválido para o assunto.');
    }
    if (mensagem.trim() === '') {
        erros.push('Mensagem não pode ser vazia.');
    }

    if (erros.length > 0) {
        return res.send(`
            <p>${erros.join('<br>')}</p>
            <a href="/batepapo?assunto=${assunto}">Voltar</a>`);
    }

    var mensagens = lerMensagens();
    mensagens.push({
        assunto,
        usuario,
        texto: mensagem,
        dataHora: new Date().toLocaleString()
    });
    salvarMensagens(mensagens);
    res.redirect(`/batepapo?assunto=${assunto}`);
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
